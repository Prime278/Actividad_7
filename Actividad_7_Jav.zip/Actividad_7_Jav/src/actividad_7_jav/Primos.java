/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package actividad_7_jav;
import java.util.Scanner;
public class Primos {
    
    //Atributos para las operaciones
    int n, num, s, x, cont;
    int [] array = new int [n];

    //Método para ingresar datos, la cantidad de numeros a identificar.
    public void leer(){
    Scanner leer = new Scanner (System.in);
    System.out.println("Ingresar la cantidad de numeros primos a calcular");
        n = leer.nextInt();
    }
    
    //Método de operacion Fibonacci
    public void primo(){
    num=0;
        while(n > 0){
            num = num +1;
            x = 1;
            cont = 0;
            while(x <= num){
                //s = num % x;
                if (num%x == 0){
                    cont = cont + 1;
                }
                x = x + 1;
            }
            //Resaltara todo los numeros primos
            if(cont == 2){
              System.out.println("El número " + num + " es primo");
                n = n - 1;
            }
        }    
    }   
}
