/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package actividad_7_jav;

public class Actividad_7_Jav {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
        //Se crean las variables a utilizar
        Primos op = new Primos();
        op.leer();
        op.primo();
        
        //Se hace llamar a la clase
        Fibonacci fi = new Fibonacci();
        
        //Se declaran las variables a tuilizar en el metodo Fibonacci
        int serie = 10, num1 = 0, num2 = 1, suma = 1;
 
        // Muestro el valor inicial
        System.out.println(num1);
         System.out.println("suceccion Fibonacci;");
         
        for (int i = 1; i < serie; i++) {
             
           
            // muestro la suma
            System.out.println(suma);
             
            //primero sumamos
            suma = num1 + num2;
            //Despues, cambiamos la segunda variable por la primera
            num1 = num2;
            //Por ultimo, cambiamos la suma por la segunda variable
            num2 = suma;
             
             
        }
    }
 
}
        
    
    

